#ifndef BASECONTROLDEVICE_H
#define BASECONTROLDEVICE_H

enum TFlagState {fsFlagOpen, fsFlagClose, fsFlagOpening, fsFlagClosing, fsError};
enum TPifMode	{ pifmOff, pifmFlag, pifmRecording, pifmSnapshot, pifmLinescanner, pifmFrameSync, pifmCenterPixel, pifmUser=0xffff };
enum TPifVersion{ pifvNone, pifvPIF, pifvPIPIF, pifvError=0xffff };

typedef struct tagSamplePoint
{
    short  ADU;
    short  Val; // temperature or voltage
	bool operator==(tagSamplePoint val) {	return (ADU == val.ADU) && (Val == val.Val); } //   '=='
	bool operator!=(tagSamplePoint val) {	return (ADU != val.ADU) || (Val != val.Val); } //   '!='
}
SamplePoint, *PSamplePoint;

typedef struct tagSamplePointTable
{
	PSamplePoint SamplePoints;
    int Size;
}
SamplePointTable, *PSamplePointTable;

#define PIFINCNT 2
#define PIFINDIGCNT 1
#define PIFOUTCNT 3

/**
 * @class BaseControlDevice
 * @brief Generic control interface to PI imagers
 */
class BaseControlDevice
{
public:

  BaseControlDevice();

  virtual ~BaseControlDevice();

  virtual int Init(unsigned long vid, unsigned long pid, bool ForceInitHID) = 0;

  virtual int Init(unsigned long vid, unsigned long pid, unsigned long serno, bool ForceInitHID, bool *SameDevice) = 0;

  virtual unsigned long InitPif(void) = 0;

  virtual int GetBuffer(unsigned char *buffer, int len) = 0;

  virtual unsigned long GetSerialNumber(void) = 0;

  virtual unsigned short GetFirmwareRev(void) = 0;

  virtual unsigned short GetHardwareRev(void) = 0;

  virtual void GetPifIn(unsigned short *pVoltage, unsigned char PifInChn) = 0;// Part of NF1080

  virtual void SetPifOut(unsigned short Voltage, unsigned char PifOutChn) = 0; // Part of NF1080

  virtual void FailSafe(bool Val) = 0; // part of NF1080

  virtual void SetTecEnable(bool on) = 0;

  virtual void GetTecEnable(bool *pVal) = 0;

  virtual void SetTempTec(float Temp) = 0;

  virtual void GetTempTec(float *pVal) = 0;

  virtual void GetFlag(TFlagState *pVal) = 0;

  virtual void SetFlag(TFlagState Val) = 0;

  virtual void SetFlagCycle(unsigned short CycleCount) = 0;

  virtual void SetTecA(unsigned short Val) = 0;

  virtual void GetTecA(unsigned short *pVal) = 0;

  virtual void SetTecB(unsigned short Val) = 0;

  virtual void GetTecB(unsigned short *pVal) = 0;

  virtual void SetTecC(unsigned short Val) = 0;

  virtual void GetTecC(unsigned short *pVal) = 0;

  virtual void SetTecD(unsigned short Val) = 0;

  virtual void GetTecD(unsigned short *pVal) = 0;

  virtual void SetSkim(unsigned short voltage) = 0;

  virtual void SetSkim_WaitForFlag(unsigned short voltage) = 0;

  virtual void GetSkim(unsigned short *pVal) = 0;

  virtual void SetSkim_Adjust(unsigned short voltage) = 0;

  virtual void GetSkim_Adjust(unsigned short *pVal) = 0;

  virtual void SetFid(unsigned short voltage) = 0;

  virtual void SetFid_WaitForFlag(unsigned short voltage) = 0;

  virtual void GetFid(unsigned short *pVal) = 0;

  virtual void SetFid_Adjust(unsigned short voltage) = 0;

  virtual void GetFid_Adjust(unsigned short *pVal) = 0;

  virtual void SetBiasEnable(bool on) = 0;

  virtual void GetBiasEnable(bool *pVal) = 0;

  virtual void SetPowerEnable(bool on) = 0;

  virtual void GetPowerEnable(bool *on) = 0;

  virtual void GetAntiFlicker(bool *on) = 0;

  virtual void SetAntiFlicker(bool on) = 0;

  virtual void SetClippedFormatPosition(unsigned short x, unsigned short y) = 0; // Part of NF1343

  virtual void GetClippedFormatPosition(unsigned short *pValx, unsigned short *pValy) = 0; // Part of NF1343

  virtual bool GetShortImagerCaps(void) = 0;

  virtual TPifMode GetPIFInMode(short PifInChn) = 0;

  virtual void SetPIFInMode(TPifMode Val, short PifInChn) = 0;

  virtual TPifMode GetPIFInDigitalMode(void) = 0;

  virtual void SetPIFInDigitalMode(TPifMode Val) = 0;

  virtual TPifMode GetPIFOutMode(short PifOutChn) = 0;

  virtual void SetPIFOutMode(TPifMode Val, short PifOutChn) = 0;

  virtual unsigned short GetPIFInFlagThreshold(void) = 0;

  virtual void SetPIFInFlagThreshold(unsigned short val) = 0;

  virtual bool GetPIFInFlagOpenIfLower(void) = 0;

  virtual void SetPIFInFlagOpenIfLower(bool val) = 0;

  virtual void SetPIFOutFlagOpen(unsigned short value, short PifOutChn) = 0;

  virtual void GetPIFOutFlagOpen(unsigned short *pVal, short PifOutChn) = 0;

  virtual void SetPIFOutFlagClosed(unsigned short value, short PifOutChn) = 0;

  virtual void GetPIFOutFlagClosed(unsigned short *pVal, short PifOutChn) = 0;

  virtual void SetPIFOutFlagMoving(unsigned short value, short PifOutChn) = 0;

  virtual void GetPIFOutFlagMoving(unsigned short *pVal, short PifOutChn) = 0;

  virtual void SetPIFOutFrameSync(unsigned short value, short PifOutChn) = 0; // Part of NF1083

  virtual void GetPIFOutFrameSync(unsigned short *pVal, short PifOutChn) = 0; // Part of NF1083

  virtual void SetPIFOutSamplePointTable(PSamplePoint Table, int TableSize, double SlopeFactor, double SlopeOffset, 
	  bool TempHighResolution, short PifOutChn) = 0; // Part of NF1283

  virtual bool GetPIFInDigitalFlagLowActive(void) = 0;

  virtual void SetPIFInDigitalFlagLowActive(bool val) = 0;

  virtual unsigned short GetPIFInThreshold(void) = 0;

  virtual void SetPIFInThreshold(unsigned short val) = 0;

  //virtual bool GetPIFInOpenIfLower(void) = 0;

  //virtual void SetPIFInOpenIfLower(bool val) = 0;

  virtual bool GetPIFInDigitalLowActive(void) = 0;

  virtual void SetPIFInDigitalLowActive(bool val) = 0;

  virtual void GetTempChip(float *pVal) = 0;

  virtual void GetTempBox(float *pVal) = 0;

  virtual void GetTempFlag(float *pVal) = 0;

  virtual TPifVersion GetPifVersion(void) = 0;

  virtual void SetLaserEnable(bool Val) = 0;

  virtual void GetLaserEnable(bool *pVal) = 0;

  virtual bool GetChecksumValid(void) = 0; // Part of NF1100

  virtual void CheckFlagSource(void) = 0; // Part of NF1080
	
  virtual int FirmwareRead(unsigned char* Daten, unsigned short count) = 0; // Part of NFI1556

  virtual int FirmwareWrite(unsigned char* Daten, unsigned short count) = 0; // Part of NFI1556

  virtual void ControlJTAGPort(unsigned char* ptr_data1, unsigned char* ptr_data2, unsigned char rw, unsigned short bit_cnt, unsigned char sel) = 0; // Part of NF1574

  virtual bool MCSFirmwareCheck(unsigned char* fw_from_file, int fw_size) = 0; // Part of NF1574

  virtual bool MCSFirmwareWrite(unsigned char* fw_data, int fw_size) = 0; // Part of NF1574
  
  void SetTempTecMax(float val);

  float GetTempTecMax();

  void SetTempTecMin(float val);

  float GetTempTecMin();

  void SetTempBoxOffset(float val);

  float GetTempBoxOffset();

  void SetTempChipFactor(float val);

  float GetTempChipFactor();

  void SetTempChipOffset(float val);

  float GetTempChipOffset();

  void SetTempFlagOffset(float val);

  float GetTempFlagOffset();

  void SetTempTecOffset(float val);

  float GetTempTecOffset();

  void SetTempTecGain(float val);

  float GetTempTecGain();

  void SetPifInOffset(float val, unsigned char PifInChn); // Part of NF1080

  float GetPifInOffset(unsigned char PifInChn); // Part of NF1080

  void SetPifInGain(float val, unsigned char PifInChn); // Part of NF1080

  float GetPifInGain(unsigned char PifInChn); // Part of NF1080

  void SetPifOutOffset(float val, unsigned char  PifOutChn); // Part of NF1080

  float GetPifOutOffset(unsigned char  PifOutChn); // Part of NF1080

  void SetPifOutGain(float val, unsigned char  PifOutChn); // Part of NF1080

  float GetPifOutGain(unsigned char  PifOutChn); // Part of NF1080

  unsigned char GetFlagSource(void); // Part of NF1080

protected:

  float TempTecMax;

  float TempTecMin;

  float TempBoxOffset;

  float TempChipFactor;

  float TempChipOffset;

  float TempFlagOffset;

  float TempTecOffset;

  float TempTecGain;

  float PifInOffset[PIFINCNT];// Part of NF1080

  float PifInGain[PIFINCNT];// Part of NF1080

  float PifOutOffset[PIFOUTCNT];// Part of NF1080

  float PifOutGain[PIFOUTCNT];// Part of NF1080

  unsigned char FlagSource; // Part of NF1080
};

#endif
