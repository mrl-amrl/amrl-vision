/******************************************************************************
 * Copyright (c) 2012-2016 All Rights Reserved, http://www.evocortex.com      *
 *  Evocortex GmbH                                                            *
 *  Emilienstr. 1                                                             *
 *  90489 Nürnberg                                                            *
 *  Germany                                                                   *
 *                                                                            *
 * Contributors:                                                              *
 *  Initial version for Linux 64-Bit platform supported by Fraunhofer IPA,    *
 *  http://www.ipa.fraunhofer.de                                              *
 *****************************************************************************/

#ifndef IRDEVICEUVC
#define IRDEVICEUVC

#include <string.h>

namespace evo
{

enum IRDeviceError
{
    IRIMAGER_SUCCESS      =  0,
    IRIMAGER_NODATA       = -1,
    IRIMAGER_DISCONNECTED = -2
};

/**
 * @class IRDeviceUVC
 * @brief UVC device interface (Linux platforms)
 * @author Stefan May (Evocortex GmbH), Matthias Wiedemann (Optris GmbH)
 */
class IRDeviceUVC
{
public:

  /**
   * Static factory method
   * @param[in] v4lPath The user might force a certain path. If NULL is passed, the path is determined automatically.
   * @þaram[in|out] Lookup parameter: If serial=0, the serial number will be determined automatically (first found device).
   *                                  If serial>0, the method searches for the specific device.
   * @param[in] videoFormatIndex PI imagers might have multiple video formats, e.g. PI400: 0==27Hz, 1==80Hz
   * @return Pointer to class instance (might be NULL, if device is not found)
   */
  static IRDeviceUVC* createInstance(char* v4lPath, unsigned long &serial, int videoFormatIndex);

  /**
   * Standard constructor
   * @param[in] devPath System path to device
   */
  IRDeviceUVC(const char* devPath=NULL);

  /**
   * Destructor
   */
  ~IRDeviceUVC();

  /**
   * Find first device with vendor and product identifier of Optris GmbH
   * @return Serial number (if successfully found)
   */
  unsigned long findFirstDevice();

  /**
   * Find device with specific serial number of Optris GmbH
   * @return Serial number (if successfully found)
   */
  unsigned long findDeviceBySerial(unsigned long serial);

  /**
   * Get UVC path
   * @return UVC path
   */
  char* getPath();

  /**
   * Get serial number of previously found device
   * @return serial number
   */
  unsigned long getSerial();

  /**
   * Force serial number
   * @param[in] serno serial number
   */
  void setSerial(unsigned long serno);

  /**
   * Open device
   * @param[in] chFormat format channel
   * @return success
   */
  int openDevice(unsigned int chFormat=0);

  /**
   * Check if device was already opened
   * @return state (open / closed)
   */
  bool isOpen();

  /**
   * Set framerate of device (numerator / denominator)
   * @param[in] numerator numerator of framerate term
   * @param[in] denominator denominator of framerate term
   */
  int setFramerate(unsigned int numerator, unsigned int denominator);

  /**
   * Start video grabbing
   */
  int startStreaming();

  /**
   * Stop video grabbing
   */
  void stopStreaming();

  /**
   * Close device
   * @return success
   */
  int closeDevice();

  /**
   * Get image width
   * @return image width
   */
  unsigned int getWidth();

  /**
   * Get image height
   * @return image height
   */
  unsigned int getHeight();

  /**
   * Get frequency of video stream
   * @return frequency of video stream
   */
  unsigned int getFrequency();

  /**
   * Acquire one frame
   * @param buffer image data
   * @param timestamp point of time at arrival via V4L2
   */
  IRDeviceError getFrame(unsigned char* buffer, double* timestamp=NULL);

  /**
   * Read uvc control
   * @param[in] id id of control
   * @param[out] value return value of read command
   * @return success
   */
  int readControl(unsigned int id, int* value);

  /**
   * Write to uvc control
   * @param[in] id id of control
   * @param[in] value value to be writte to uvc control
   * @return success
   */
  int writeControl(unsigned int id, int value);

protected:

  char* _path;

  int _height;

  int _width;

  int _freq;

  unsigned long _serno;

private:

  /**
   * Release frame binding
   */
  int releaseFrame();

  int initMmap();

  int xioctl(int request, void *arg);

  /**
   * Generic find method
   * @param[in] serial Serial number to be found, if serial==0, then first device is returned
   * @return Serial number (if successfully found)
   */
  unsigned long findDevice(unsigned long serial);

  int _fd;

  struct buffer
  {
    void * start;
    size_t length;
  };

  buffer* _buffers;

  unsigned int _cntBuffers;

  int _index;

  size_t _len;

  bool _isStreaming;
};

} //namespace

#endif // IRDEVICEUVC
